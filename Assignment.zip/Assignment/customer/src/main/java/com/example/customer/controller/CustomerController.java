package com.example.customer.controller;

import java.util.List;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.customer.entity.Customer;
import com.example.customer.entity.ResponseResource;
import com.example.customer.exception.FairGlowException;
import com.example.customer.service.CustomerService;

@RestController
@RequestMapping("/customer")

public class CustomerController {
	@Autowired
	CustomerService customerService;
	

    @PostMapping("/create")
	public ResponseResource<Customer> saveCustomer(@RequestBody Customer customer) throws FairGlowException{
		return new ResponseResource<>("OK", "SUCCESS",
				customerService.saveCustomer(customer),MDC.get("MDC_TOKEN"));
	}
    @GetMapping("/getAll")
	public ResponseResource<List<Customer>> getAllCustomers() throws FairGlowException{
		return new ResponseResource<>("OK", "SUCCESS",
				customerService.getAllCustomers(),MDC.get("MDC_TOKEN"));
	}
    @GetMapping("/get/{name}")
	public ResponseResource<Customer> getCustomerByName(@PathVariable("name") String name) throws FairGlowException{
		return new ResponseResource<>("OK", "SUCCESS",
				customerService.getCustomerByName(name),MDC.get("MDC_TOKEN"));
	}
}
