package com.example.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.customer.entity.Customer;
import com.example.customer.exception.FairGlowException;
import com.example.customer.repository.CustomerRepository;

@Service
@Transactional
public class CustomerService {
 
    @Autowired
    private CustomerRepository customerRepository;
 
    public Customer saveCustomer(Customer customer) throws FairGlowException {
        if (customer.getName()==null || "".equals(customer.getName().trim())) {
        	throw new FairGlowException("Please enter valid Name");
        }
        Customer customer1= customerRepository.findByName(customer.getName());
   	 	if (customer1!=null ) {
        	throw new FairGlowException("The given customer name is already present");
        }
        if (customer.getAddress()==null || "".equals(customer.getAddress().trim())) {
        	throw new FairGlowException("Please enter valid Address");
        }
        if (customer.getCode()==null || "".equals(customer.getCode().trim())) {
        	throw new FairGlowException("Please enter valid Code");
        }
    	return customerRepository.save(customer);
    }
 
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
 
    public Customer getCustomerByName(String name) throws FairGlowException {
    	Customer customer= customerRepository.findByName(name);
    	 if (customer==null ) {
         	throw new FairGlowException("The given customer name is not present");
         }
    	 return customer;
    }
}
