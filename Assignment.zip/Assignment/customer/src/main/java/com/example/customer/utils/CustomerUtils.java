package com.example.customer.utils;

public class CustomerUtils 
{

	static String alphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
	public static String generateUid(int length) {
		StringBuilder sb = new StringBuilder(length);
		 
		  for (int i = 0; i < length; i++) {
		   int index
		    = (int)(alphaNumericString.length()
		      * Math.random());
		   sb.append(alphaNumericString
		      .charAt(index));
		  }
		 
		  return sb.toString();
	}

}
