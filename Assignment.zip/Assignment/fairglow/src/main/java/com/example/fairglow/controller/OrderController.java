package com.example.fairglow.controller;

import java.util.List;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fairglow.entity.CustomerOrder;
import com.example.fairglow.entity.ReportDto;
import com.example.fairglow.entity.ResponseResource;
import com.example.fairglow.exception.FairGlowException;
import com.example.fairglow.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/placeOrder")
	public ResponseResource<CustomerOrder> placeOrder(@RequestBody CustomerOrder customerOrder) throws FairGlowException{
		return new ResponseResource<>("OK", "SUCCESS",
				orderService.placeOrder(customerOrder),MDC.get("MDC_TOKEN"));
	}
	
	@PostMapping("/report")
	public  ResponseResource<List<CustomerOrder>> getReport(@RequestBody ReportDto report) throws FairGlowException{
		return new ResponseResource<>("OK", "SUCCESS",
				orderService.getReport(report),MDC.get("MDC_TOKEN"));
	}
}
