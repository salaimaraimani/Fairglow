package com.example.fairglow.exception;

/**
 * Custom exception for banking application
 *
 */
@SuppressWarnings("serial")
public class FairGlowException extends Exception{
	
	public FairGlowException(String message) {
		super(message);
	}

}
