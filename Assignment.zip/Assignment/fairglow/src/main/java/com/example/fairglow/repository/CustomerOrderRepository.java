package com.example.fairglow.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fairglow.entity.CustomerOrder;



public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long>{
	public List<CustomerOrder> findByCustomerNameAndPurchaseDateBetweenOrderById(String customerName,Date startTime, Date endTime); 
	
	public List<CustomerOrder> findByProductNameAndPurchaseDateBetweenOrderById(String productName,Date startTime, Date endTime); 
}
