package com.example.fairglow.service;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.example.fairglow.entity.CustomerOrder;
import com.example.fairglow.entity.ReportDto;
import com.example.fairglow.exception.FairGlowException;
import com.example.fairglow.repository.CustomerOrderRepository;


@Service
@Transactional
public class OrderService {
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CustomerOrderRepository customerOrderRepository;

	public CustomerOrder placeOrder(CustomerOrder customerOrder) throws FairGlowException
	{
		 if (customerOrder.getCustomerName()==null || "".equals(customerOrder.getCustomerName().trim())) {
	        	throw new FairGlowException("Please enter valid Customer Name");
	     }
		 if (customerOrder.getProductName()==null || "".equals(customerOrder.getProductName().trim())) {
	        	throw new FairGlowException("Please enter valid Product Name");
		 }
		 if (customerOrder.getQuantity()<=0 ) {
	        	throw new FairGlowException("The quantity must be greater than zero");
		 }
		 
		 restTemplate.exchange("http://localhost:9000/api/customer/get/"+customerOrder.getCustomerName(),HttpMethod.GET,new HttpEntity<String>(new HttpHeaders()), String.class);
		 
		 restTemplate.exchange("http://localhost:7000/api/product/order/"+customerOrder.getProductName()+"/"+customerOrder.getQuantity(),HttpMethod.GET,new HttpEntity<String>(new HttpHeaders()), String.class);		 
		 
		 customerOrder.setPurchaseDate(new Date());
		 return customerOrderRepository.save(customerOrder);
	}
	public List<CustomerOrder> getReport(ReportDto report) throws FairGlowException{
		List<CustomerOrder> orderList = null;
		if(report.getStartDate()==null || report.getEndDate()==null || report.getStartDate().after(report.getEndDate())) {
			throw new FairGlowException("Please enter valid start date and end date");
		}
		if (report.getCustomerName()!= null) {
			orderList= customerOrderRepository.findByCustomerNameAndPurchaseDateBetweenOrderById(report.getCustomerName(), report.getStartDate(), report.getEndDate());
		}
		else if (report.getProductName()!= null) {
			orderList= customerOrderRepository.findByProductNameAndPurchaseDateBetweenOrderById(report.getProductName(), report.getStartDate(), report.getEndDate());
		}
		else {
			throw new FairGlowException("Please enter CustomerName/ProductName");
		}
		if (orderList==null || orderList.isEmpty()) {
			throw new FairGlowException("Either order was not placed for given CustomerName/ProductName or CustomerName/ProductName is invalid");
		
		}
		return orderList;	
	}
}
