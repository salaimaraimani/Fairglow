package com.example.fairglow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FairglowApplicationTests {

	@Test
	void contextLoads() {
	}

}
