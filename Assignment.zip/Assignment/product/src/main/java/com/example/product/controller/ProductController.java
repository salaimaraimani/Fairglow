package com.example.product.controller;


import java.util.List;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.entity.Product;
import com.example.product.entity.ResponseResource;
import com.example.product.exception.FairGlowException;
import com.example.product.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productService;
	
	@PostMapping("/create")
	public ResponseResource<Product> saveProduct(@RequestBody Product product) throws FairGlowException {
		return new ResponseResource<>("OK", "SUCCESS",
				productService.saveProduct(product),MDC.get("MDC_TOKEN"));
	}
	
	@GetMapping("/getAll")
	public ResponseResource<List<Product>> getAllProducts() {
		return new ResponseResource<>("OK", "SUCCESS",
				productService.getAllProducts(),MDC.get("MDC_TOKEN"));
	}
	
	@GetMapping("/get/{name}")
	public ResponseResource<Product> getProductByName(@PathVariable("name") String productName) throws FairGlowException {
		return new ResponseResource<>("OK", "SUCCESS",
				productService.getProductByName(productName),MDC.get("MDC_TOKEN"));
	}

	@GetMapping("/update/{name}/{quantity}")
	public ResponseResource<Boolean> updateProductQuantity(@PathVariable("name") String productName,@PathVariable("quantity") int quantity) throws FairGlowException {
		return new ResponseResource<>("OK", "SUCCESS",
				productService.updateProductQuantity(productName,quantity),MDC.get("MDC_TOKEN"));
	}

	@GetMapping("/order/{name}/{quantity}")
	public ResponseResource<Boolean> placeOrder(@PathVariable("name") String productName,@PathVariable("quantity") int quantity) throws FairGlowException {
		return new ResponseResource<>("OK", "SUCCESS",
				productService.placeOrder(productName,quantity),MDC.get("MDC_TOKEN"));
	}

}
