package com.example.product.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.entity.Product;
import com.example.product.exception.FairGlowException;
import com.example.product.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	public Product saveProduct(Product product) throws FairGlowException {
		if (product.getName() == null || "".equals(product.getName().trim())) {
			throw new FairGlowException("Please enter valid Product Name");
		}
		Product product1 = productRepository.findByName(product.getName());
		if (product1 != null) {
			throw new FairGlowException("The given product name is already present");
		}
		if (product.getQuantity() <= 0) {
			throw new FairGlowException("Quantity should be greater than zero");
		}
		if (product.getExpiryDate() == null) {
			throw new FairGlowException("Please enter valid Expiry Date");
		}
		return productRepository.save(product);

	}

	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	public Product getProductByName(String productName) throws FairGlowException {
		Product product1 = productRepository.findByName(productName);
		if (product1 == null) {
			throw new FairGlowException("The given product name is not present");
		}
		return product1;
	}

	public boolean updateProductQuantity(String productName, int quantity) throws FairGlowException {
		Product product = productRepository.findByName(productName);
		if (product == null) {
			throw new FairGlowException("The given product name is not present");
		}
		if (quantity <= 0) {
			throw new FairGlowException("Quantity should be greater than zero");
		}

		product.setQuantity(quantity);
		productRepository.save(product);
		return true;
	}

	public boolean placeOrder(String productName, int quantity) throws FairGlowException {
		Product product = productRepository.findByName(productName);
		if (product == null) {
			throw new FairGlowException("The given product name is not present");
		}
		if (quantity > product.getQuantity()) {
			throw new FairGlowException("Quantity entered exceeds the stock limit");
		}
		Date date = new Date();
		if (date.after(product.getExpiryDate())) {
			throw new FairGlowException("Product Expired");
		}

		product.setQuantity(product.getQuantity() - quantity);
		productRepository.save(product);
		return true;
	}

}
